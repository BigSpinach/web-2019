[toc]


----

#一、Node的安装

##1.1-安装包的方式(不推荐)
 
`安装方式一--------安装包的方式（不推荐）`
>  安装包的方式（不推荐）
+ Darwin：链接
+  Windows：x64 / x86

> 安装过程：
+  Next
+ Next
+ Next

> 更新 Node 版本


----------


+ 重新下载最新的安装包；

> 问题：覆盖安装即可
+  以前版本安装的很多全局的工具包需要重新安装
+ 无法回滚到之前的版本
+ 无法在多个版本之间切换（很多时候我们要使用特定版本）

##1.2 NVM 的方式安装
`安装方式二`
> nvm(node版本管理工具,可以运行在多种操作系统上)

`  Windows 下的 nvm-windows 工具：`
### 1.2.1 下载： https://github.com/coreybutler/nvm-windows/releases，
- 这里有四个可下载的文件：
	 + nvm-noinstall.zip： 绿色免安装版本，但是使用之前需要配置
	 + nvm-setup.zip：这是一个安装包，下载之后点击安装，无需配置就可以使用
	 + Source code(zip)：zip压缩的源码
	 + Sourc code(tar.gz)：tar.gz的源码，一般用于*nix系统
 


###1.2.2 安装之前的准备工作
**注意：**在安装nvm for windows之前，你需要卸载任何现有版本的node.js。并且需要删除现有的nodejs安装目录（例如："C:\Program Files\nodejs’）。因为，nvm生成的symlink（符号链接/超链接)不会覆盖现有的（甚至是空的）安装目录。
你还需要删除现有的npm安装位置（例如“C:\Users\weiqinl\AppData\Roaming\npm”），以便正确使用nvm安装位置。

###1.2.3 安装
**这里将两种安装方式**
@(第一种：安装包安装 nvm-setup.zip)

> 1.解压 nvm-setup.zip得到 nvm-setup.exe文件
> 2.执行 nvm-setup.exe
> 3.选择安装路径
![Alt text](./1533231746193.png)

> 4.next之后,(这个目录是设置nodejs的快捷方式存放的目录)
![Alt text](./1533232049981.png)

> 5.Next-->Install-->Finish完成本次安装。


*************

@(第二种：绿色安装 nvm-noinstall.zip)

 1.解压到一个全英文路径
  ![Alt text](./1533232538124.png)
 
 2. 编辑解压目录下的`settings.txt`文件（不存在则新建)
	 + root 配置为当前 nvm.exe 所在目录
	 + path 配置为 node 快捷方式所在的目录
	 + arch 配置为当前操作系统的位数（32/64）
	 + proxy 不用配置

![Alt text](./1533233074513.png)
3.配置环境变量
注： 配置环境变量 可以通过 window+r  : sysdm.cpl
  `NVM_HOME = 当前 nvm.exe 所在目录`
  `NVM_SYMLINK = node 快捷方式所在的目录`
  `PATH += %NVM_HOME%;%NVM_SYMLINK%;`

![Alt text](./1533284371433.png)

  打开CMD通过`set [name]`命令查看环境变量是否配置成功
  `配置失败`
  ![Alt text](./1533235113854.png)
  `配置成功`
![Alt text](./1533284499842.png)

`PowerShell中是通过`dir env:[name]`命令`

>NVM使用说明：https://github.com/coreybutler/nvm-windows/








###1.2.4  检测 (检查是否安装成功)
> 命令行输入nvm查看
![Alt text](./1533234237953.png)

###1.2.5 升级

> 如果要升级的话，请重新[下载最新的安装程序]( https://github.com/coreybutler/nvm-windows/releases)。并直接运行安装程序。它将安全的覆盖需要更新的文件，而无需关心nodejs的安装。
此次安装需要确保和上次使用相同的安装目录。
如果你最初安装到默认位置，则只需一直点击"下一步"，直到完成。


###1.2.6  nvm的使用
> nvm for windows是一个命令行工具，在控制台输入nvm,就可以看到它的命令用法。基本命令有：

>**nvm arch [32|64] **： 显示node是运行在32位还是64位模式。指定32或64来覆盖默认体系结构。
**nvm install <version> [arch]**： 该可以是node.js版本或最新稳定版本latest。（可选[arch]）指定安装32位或64位版本（默认为系统arch）。设置[arch]为all以安装32和64位版本。在命令后面添加--insecure ，可以绕过远端下载服务器的SSL验证。
**nvm list [available]**： 列出已经安装的node.js版本。可选的available，显示可下载版本的部分列表。这个命令可以简写为nvm ls [available]。
**nvm on**： 启用node.js版本管理。
**nvm off**： 禁用node.js版本管理(不卸载任何东西)
**nvm proxy [url]**： 设置用于下载的代理。留[url]空白，以查看当前的代理。设置[url]为none删除代理。
**nvm node_mirror [url]**：设置node镜像，默认为https://nodejs.org/dist/.。我建议设置为淘宝的镜像https://npm.taobao.org/mirrors/node/
**nvm npm_mirror [url]**：设置npm镜像，默认为https://github.com/npm/npm/archive/。我建议设置为淘宝的镜像https://npm.taobao.org/mirrors/npm/
**nvm uninstall <version>**： 卸载指定版本的nodejs。
**nvm use [version] [arch]**： 切换到使用指定的nodejs版本。可以指定32/64位[arch]。nvm **use <arch>**将继续使用所选版本，但根据提供的值切换到32/64位模式的<arch>
**nvm root [path]**： 设置 nvm 存储node.js不同版本的目录 ,如果未设置，将使用当前目录。
**nvm version**： 显示当前运行的nvm版本，可以简写为nvm -v


>  **nvm ls-remot**“：列出全部可以安装的版本号
>  **nvm install 版本号**   ：安装指定版本
>  **nvm use 版本号** ： 切换指定版本，切换效果是全局的
>  **nvm current**：查看当前使用的版本
> **nvm ls**： 查看该系统已经安装的版本，这个命令也能看到当前使用的是哪个版本
**********

##1.3 nodejs的安装使用流程
>nvm ls   // 查看目前已经安装的版本
nvm install 6.10.0  // 安装指定的版本的nodejs
nvm use 6.10.0  // 使用指定版本的nodejs
nvm install latest//安装最新版本

![Alt text](./1533285359358.png)

`安装node	`
![Alt text](./1533286337528.png)
`本地显示效果`
![Alt text](./1533286403495.png)

`再次切换node版本`
![Alt text](./1533286465603.png)
`本地显示效果`
![Alt text](./1533286519472.png)



##1.4 安装 NPM
>NPM 不需要单独安装。默认在安装 Node 的时候，会连带一起安装 NPM。但是，Node 附带的 NPM 可能不是最新版本，最好用下面的命令，更新到最新版本。
`$ npm install npm –g`

`配置全局npm`
![Alt text](./1533289596023.png)



