[toc]

#珠峰node

##1 .电脑扫盲
![Alt text](./1536483720097.png)

![Alt text](./1536483797620.png)

![Alt text](./1536483912313.png)

![Alt text](./1536483982621.png)

2.
![Alt text](./1536485386833.png)



![Alt text](./1536485707792.png)

![Alt text](./1536559211995.png)


![Alt text](./1536559495879.png)


![Alt text](./1536561890324.png)


3.uri/url/urn

![Alt text](./1536562202992.png)

![Alt text](./1536562637556.png)

![Alt text](./1536562847191.png)


![Alt text](./1536563278916.png)

![Alt text](./1536647198350.png)



##2. 初识node

###2.1 什么是node
![Alt text](./1536564664368.png)
###2.2 node  && 浏览器
![Alt text](./1536565820345.png)
### 2.3 js代码如何在node中运行
![Alt text](./1536566757043.png)


### 2.4 node模块
> 内置模块

> 自定义模块
![Alt text](./1536572265473.png)

`测试练习`
![Alt text](./1536572393811.png)


`a.js`
	
	//a模块实现任意数求和
	function sum(){
		//获取arguments
		//遍历arguments，保存到一个变量中
		var total = null;
		for(var i = 0; i < arguments.length; i++){	
			if(!isNaN(Number(arguments[i]))){
				total += Number(arguments[i]);		
			}
		}
		return total;
	}
	 //var total1 = sum(1,2,3,4);
	 //console.log(total1);
	 //
	module.exports = {
	 	sum :sum
	 }

`b.js`

	//b模块实现，传参*100的返回结果
	function sum(a){
		return a*=100;
	}
	module.exports = {
	 	sum :sum
	 }

`c.js`
	
	//c模块实现
	//第一步 ：调取a模块的方法求1~4的和
	//第二步 ：调取b模块的方法对使用a模块方法求和后的值 使用b模块的方法（对a模块的去和数*100的操作）
	//输出计算后的结果
	
	var a = require('./a');
	var b = require('./b');
	
	var total = a.sum(1,2,3,4);
	var total2 = b.sum(total);
	
	console.log(total2);


> 第三方模块
![Alt text](./1536567049538.png)
![Alt text](./1536571995091.png)



#### 2.4.1 内置模块
`整体感知`

![Alt text](./1536642415163.png)

![Alt text](./1536642398872.png)

![Alt text](./1536642434220.png)


![Alt text](./1536643309623.png)
![Alt text](./1536643437075.png)

	//1.导包
	var http = require("http");
	var fs = require("fs");
	var url = require("url");
	
	//console.log(http);
	
	//2.启动服务
	var server = http.createServer(function(request,response){
		//console.log(request);
		//console.log(response);
		//console.log(url);//[Function: Rul]
		//console.log(fs);   
		
		//3.处理业务
		console.log(request.url);
		var urlObj = url.parse(request.url,true);
		var pathname = urlObj.pathname;
		var query = urlObj.query;
	
		console.log(pathname.toString());//null?
	
		if(pathname === "/demo.html"){
			var context = fs.readFileSync('./demo.html','utf-8');
			response.write(context);
			response.end();
		}else{
			console.log('路径不对，读取失败');
		}
	
	});
	
	//4. 监听端口
	server.listen(3300,function(){
		console.log('server runing success at port 3300');
	});



##### 2.4.1.1`url`模块
	
	var url = require('url');
	var str = "https://www.gscq.me/my.htm？name=bigspinach&age=18#abcdefg";	
	//console.log(url);
	/*
		{ Url: [Function: Url],
		  parse: [Function: urlParse],
		  resolve: [Function: urlResolve],
		  resolveObject: [Function: urlResolveObject],
		  format: [Function: urlFormat],
		  URL: [Function: URL],
		  URLSearchParams: [Function: URLSearchParams],
		  domainToASCII: [Function: domainToASCII],
		  domainToUnicode: [Function: domainToUnicode] 
		}
	 */

`url-parse(str)`

	var url = require('url');
	var str = "https://www.gscq.me/my.htm？name=bigspinach&age=18#abcdefg";	
	//console.log(url.parse(str));
	/*
		Url {
		  protocol: 'https:',
		  slashes: true,
		  auth: null,
		  host: 'www.gscq.me',
		  port: null,
		  hostname: 'www.gscq.me',
		  hash: '#abcdefg',
		  search: null,
		  query: null,
		  pathname: '/my.htm？name=bigspinach&age=18',
		  path: '/my.htm？name=bigspinach&age=18',
		  href: 'https://www.gscq.me/my.htm？name=bigspinach&age=18#abcdefg' 
		}
	 */


`url-parse(str,true)`

	var url = require('url');
	var str = "https://www.gscq.me/my.htm？name=bigspinach&age=18#abcdefg";	
	console.log(url.parse(str,true));
	/*
		Url {
		  protocol: 'https:',
		  slashes: true,
		  auth: null,
		  host: 'www.gscq.me',
		  port: null,
		  hostname: 'www.gscq.me',
		  hash: '#abcdefg',
		  search: '',
		  query: {},
		  pathname: '/my.htm？name=bigspinach&age=18',
		  path: '/my.htm？name=bigspinach&age=18',
		  href: 'https://www.gscq.me/my.htm？name=bigspinach&age=18#abcdefg' 
		}
	 */

##### 2.4.1.2`fs`模块
	
	{
	  constants: {
	    O_RDONLY: 0,
	    O_WRONLY: 1,
	    O_RDWR: 2,
	    S_IFMT: 61440,
	    S_IFREG: 32768,
	    S_IFDIR: 16384,
	    S_IFCHR: 8192,
	    S_IFLNK: 40960,
	    O_CREAT: 256,
	    O_EXCL: 1024,
	    O_TRUNC: 512,
	    O_APPEND: 8,
	    F_OK: 0,
	    R_OK: 4,
	    W_OK: 2,
	    X_OK: 1,
	    UV_FS_COPYFILE_EXCL: 1,
	    COPYFILE_EXCL: 1
	  },
	  Stats: [Function: Stats],
	  F_OK: 0,
	  R_OK: 4,
	  W_OK: 2,
	  X_OK: 1,
	  access: [Function],
	  accessSync: [Function],
	  exists: [Function],
	  existsSync: [Function],
	  readFile: [Function],
	  readFileSync: [Function],
	  close: [Function],
	  closeSync: [Function],
	  open: [Function],
	  openSync: [Function],
	  read: [Function],
	  readSync: [Function],
	  write: [Function],
	  writeSync: [Function],
	  rename: [Function],
	  renameSync: [Function],
	  truncate: [Function],
	  truncateSync: [Function],
	  ftruncate: [Function],
	  ftruncateSync: [Function],
	  rmdir: [Function],
	  rmdirSync: [Function],
	  fdatasync: [Function],
	  fdatasyncSync: [Function],
	  fsync: [Function],
	  fsyncSync: [Function],
	  mkdir: [Function],
	  mkdirSync: [Function],
	  readdir: [Function],
	  readdirSync: [Function],
	  fstat: [Function],
	  lstat: [Function],
	  stat: [Function],
	  fstatSync: [Function],
	  lstatSync: [Function],
	  statSync: [Function],
	  readlink: [Function],
	  readlinkSync: [Function],
	  symlink: [Function],
	  symlinkSync: [Function],
	  link: [Function],
	  linkSync: [Function],
	  unlink: [Function],
	  unlinkSync: [Function],
	  fchmod: [Function],
	  fchmodSync: [Function],
	  chmod: [Function],
	  chmodSync: [Function],
	  fchown: [Function],
	  fchownSync: [Function],
	  chown: [Function],
	  chownSync: [Function],
	  _toUnixTimestamp: [Function: toUnixTimestamp],
	  utimes: [Function],
	  utimesSync: [Function],
	  futimes: [Function],
	  futimesSync: [Function],
	  writeFile: [Function],
	  writeFileSync: [Function],
	  appendFile: [Function],
	  appendFileSync: [Function],
	  watch: [Function],
	  watchFile: [Function],
	  unwatchFile: [Function],
	  realpathSync: [Function: realpathSync],
	  realpath: [Function: realpath],
	  mkdtemp: [Function],
	  mkdtempSync: [Function],
	  copyFile: [Function],
	  copyFileSync: [Function],
	  createReadStream: [Function],
	  ReadStream: {
	    [Function: ReadStream]
	    super_: {
	      [Function: Readable]
	      ReadableState: [Function: ReadableState],
	      super_: [Object],
	      _fromList: [Function: fromList]
	    }
	  },
	  FileReadStream: {
	    [Function: ReadStream]
	    super_: {
	      [Function: Readable]
	      ReadableState: [Function: ReadableState],
	      super_: [Object],
	      _fromList: [Function: fromList]
	    }
	  },
	  createWriteStream: [Function],
	  WriteStream: {
	    [Function: WriteStream]
	    super_: {
	      [Function: Writable] WritableState: [Function: WritableState],
	      super_: [Object]
	    }
	  },
	  FileWriteStream: {
	    [Function: WriteStream]
	    super_: {
	      [Function: Writable] WritableState: [Function: WritableState],
	      super_: [Object]
	    }
	  }
	}



##### 2.4.1.3`http`模块

	{ _connectionListener: [Function: connectionListener],
	  METHODS:
	   [ 'ACL',
	     'BIND',
	     'CHECKOUT',
	     'CONNECT',
	     'COPY',
	     'DELETE',
	     'GET',
	     'HEAD',
	     'LINK',
	     'LOCK',
	     'M-SEARCH',
	     'MERGE',
	     'MKACTIVITY',
	     'MKCALENDAR',
	     'MKCOL',
	     'MOVE',
	     'NOTIFY',
	     'OPTIONS',
	     'PATCH',
	     'POST',
	     'PROPFIND',
	     'PROPPATCH',
	     'PURGE',
	     'PUT',
	     'REBIND',
	     'REPORT',
	     'SEARCH',
	     'SOURCE',
	     'SUBSCRIBE',
	     'TRACE',
	     'UNBIND',
	     'UNLINK',
	     'UNLOCK',
	     'UNSUBSCRIBE' ],
	  STATUS_CODES:
	   { '100': 'Continue',
	     '101': 'Switching Protocols',
	     '102': 'Processing',
	     '200': 'OK',
	     '201': 'Created',
	     '202': 'Accepted',
	     '203': 'Non-Authoritative Information',
	     '204': 'No Content',
	     '205': 'Reset Content',
	     '206': 'Partial Content',
	     '207': 'Multi-Status',
	     '208': 'Already Reported',
	     '226': 'IM Used',
	     '300': 'Multiple Choices',
	     '301': 'Moved Permanently',
	     '302': 'Found',
	     '303': 'See Other',
	     '304': 'Not Modified',
	     '305': 'Use Proxy',
	     '307': 'Temporary Redirect',
	     '308': 'Permanent Redirect',
	     '400': 'Bad Request',
	     '401': 'Unauthorized',
	     '402': 'Payment Required',
	     '403': 'Forbidden',
	     '404': 'Not Found',
	     '405': 'Method Not Allowed',
	     '406': 'Not Acceptable',
	     '407': 'Proxy Authentication Required',
	     '408': 'Request Timeout',
	     '409': 'Conflict',
	     '410': 'Gone',
	     '411': 'Length Required',
	     '412': 'Precondition Failed',
	     '413': 'Payload Too Large',
	     '414': 'URI Too Long',
	     '415': 'Unsupported Media Type',
	     '416': 'Range Not Satisfiable',
	     '417': 'Expectation Failed',
	     '418': 'I\'m a teapot',
	     '421': 'Misdirected Request',
	     '422': 'Unprocessable Entity',
	     '423': 'Locked',
	     '424': 'Failed Dependency',
	     '425': 'Unordered Collection',
	     '426': 'Upgrade Required',
	     '428': 'Precondition Required',
	     '429': 'Too Many Requests',
	     '431': 'Request Header Fields Too Large',
	     '451': 'Unavailable For Legal Reasons',
	     '500': 'Internal Server Error',
	     '501': 'Not Implemented',
	     '502': 'Bad Gateway',
	     '503': 'Service Unavailable',
	     '504': 'Gateway Timeout',
	     '505': 'HTTP Version Not Supported',
	     '506': 'Variant Also Negotiates',
	     '507': 'Insufficient Storage',
	     '508': 'Loop Detected',
	     '509': 'Bandwidth Limit Exceeded',
	     '510': 'Not Extended',
	     '511': 'Network Authentication Required' },
	  Agent:
	   { [Function: Agent]
	     super_:
	      { [Function: EventEmitter]
	        EventEmitter: [Circular],
	        usingDomains: false,
	        defaultMaxListeners: [Getter/Setter],
	        init: [Function],
	        listenerCount: [Function] },
	     defaultMaxSockets: Infinity },
	  ClientRequest: { [Function: ClientRequest] super_: { [Function: OutgoingMessage] super_: [Object] } },
	  globalAgent:
	   Agent {
	     domain: null,
	     _events: { free: [Function] },
	     _eventsCount: 1,
	     _maxListeners: undefined,
	     defaultPort: 80,
	     protocol: 'http:',
	     options: { path: null },
	     requests: {},
	     sockets: {},
	     freeSockets: {},
	     keepAliveMsecs: 1000,
	     keepAlive: false,
	     maxSockets: Infinity,
	     maxFreeSockets: 256 },
	  IncomingMessage:
	   { [Function: IncomingMessage]
	     super_:
	      { [Function: Readable]
	        ReadableState: [Function: ReadableState],
	        super_: [Object],
	        _fromList: [Function: fromList] } },
	  OutgoingMessage:
	   { [Function: OutgoingMessage]
	     super_:
	      { [Function: Stream]
	        super_: [Object],
	        Readable: [Object],
	        Writable: [Object],
	        Duplex: [Object],
	        Transform: [Object],
	        PassThrough: [Object],
	        Stream: [Circular],
	        _isUint8Array: [Function: isUint8Array],
	        _uint8ArrayToBuffer: [Function: _uint8ArrayToBuffer] } },
	  Server: { [Function: Server] super_: { [Function: Server] super_: [Object] } },
	  ServerResponse: { [Function: ServerResponse] super_: { [Function: OutgoingMessage] super_: [Object] } },
	  createServer: [Function: createServer],
	  get: [Function: get],
	  request: [Function: request] }

`http-createServer(function(request,response){})`




###2.5 静态文件资源处理

`课题引入`
![Alt text](./1536657286786.png)

![Alt text](./1536657499799.png)


优化
![Alt text](./1536657719291.png)

![Alt text](./1536657956019.png)

mime类型

![Alt text](./1536660709854.png)

![Alt text](./1536658311234.png)
![Alt text](./1536658358709.png)


![Alt text](./1536658426378.png)
![Alt text](./1536658481326.png)

![Alt text](./1536658523510.png)
![Alt text](./1536658540188.png)


![Alt text](./1536658584895.png)




![Alt text](./1536658718940.png)

	
	

note
![Alt text](./1536660720632.png)
![Alt text](./1536660788181.png)
![Alt text](./1536660815313.png)
![Alt text](./1536660858459.png)
![Alt text](./1536661048591.png)
![Alt text](./1536661334493.png)

![Alt text](./1536661397542.png)




![Alt text](./1536660746446.png)


##3. ajax
![Alt text](./1536718660755.png)

xhr.readyState
![Alt text](./1536719060232.png)

xhr.status
![Alt text](./1536719328346.png)

![Alt text](./1536719931848.png)

![Alt text](./1536720095216.png)

xhr.send()
![Alt text](./1536720170876.png)




###3.1 ajax 兼容ie低版本
![Alt text](./1536725295444.png)

`js惰性思想`
![Alt text](./1536725076294.png)



![Alt text](./1536725413921.png)
![Alt text](./1536725608739.png)

![Alt text](./1536725689825.png)


![Alt text](./1536725815738.png)


![Alt text](./1536725825211.png)
![Alt text](./1536725815738.png)

createXHR()
![Alt text](./1536739593421.png)


### 3.2 xhr.open()

![Alt text](./1536731488839.png)
![Alt text](./1536731507608.png)

####3.2.1 get
![Alt text](./1536731569385.png)
get和delete和head保持一致
####3.2.2 post
![Alt text](./1536731637094.png)
post 和post保持一致


###3.3 get 与post的区别
![Alt text](./1536731951199.png)
![Alt text](./1536731964823.png)


###3.4 ajax中的同步(sync)和异步(async)
引入
![Alt text](./1536732954688.png)

![Alt text](./1536733039482.png)

![Alt text](./1536736542880.png)

ajax中的
![Alt text](./1536736927516.png)


![Alt text](./1536737589135.png)
![Alt text](./1536738176527.png)

![Alt text](./1536738329116.png)

![Alt text](./1536738578421.png)

![Alt text](./1536738698857.png)


![Alt text](./1536739073608.png)
![Alt text](./1536739109190.png)

设置请求头部信息
![Alt text](./1536739387500.png)

![Alt text](./1536739352337.png)

![Alt text](./1536739461323.png)



![Alt text](./1536739817730.png)



###3.5 编写简易的ajax方法库

![Alt text](./1536740089342.png)

![Alt text](./1536740165536.png)

![Alt text](./1536740210398.png)

![Alt text](./1536740270516.png)


![Alt text](./1536740411586.png)

![Alt text](./1536740504164.png)
![Alt text](./1536740530272.png)
 

![Alt text](./1536740580120.png)

![Alt text](./1536740674403.png)

![Alt text](./1536744589268.png)

	~ function() {
	//ajax方法： 实现AJAX请求的公用方法；
	//当一个方法传递的参数值过多，而且不固定时，我们使用对象同一传值法
	function ajax(options) {

		var _default = {
			url: "",
			type: "get",
			dataType: "json",
			async: "true",
			data: null,
			getHead: null,
			success: null
		};

		for (var key in options) {
			if (options.hasOwnProperty(key)) {
				_default[key] = options[key];
			}
		};

		//如果请求的方式是GET，我们需要在请求地址末尾加上随机数来清除缓存
		if (_default.type === "get") {
			_default.url.indexOf("?") >= 0 ? _default.url += "&" : _default.url += "?";
			_default.url += "_=" + Math.random();
		};

		var xhr = createXHR();
		xhr.open(_default.type, _default.url, _default.async);


		xhr.onreadystatechange = function() {
			if (/^2\d{2}$/.test(xhr.status)) {
				if (xhr.readyState === 2) {
					if (typeof _default.getHead === "function") {
						//如果_default.getHead方法存在，并且是一个方法的时候，改变方法中的this位xhr对象
						_default.getHead.call(xhr);
					}
				}

				if (xhr.readyState === 4) {
					var val = xhr.responseText;
					if (_default.dataType === "json") {
						val = "JSON" in window ? JSON.parse(val) : eval("(" + val + ")");
					}
					_default.success && _default.success.call(xhr, val);
				}
			}
		}

		xhr.send(_default.data);
	}

	//兼容低版本IE浏览器的获取ajax对象的方法
	function createXHR() {
		var xhr = null,
			flag = false,
			ary = [
				function() { // code for IE7+, Firefox, Chrome, Opera, Safari
					return new XMLHttpRequest;
				},
				function() { // code for IE6, IE5
					return new ActiveXObject("Microsoft.XMLHTTP");
				},
				function() {
					return new ActiveXObject("Msxml2.XMLHTTP");
				},
				function() {
					return new ActiveXObject("Msxml3.XMLHTTP");
				}
			];

		for (var i = 0, len = ary.length; i < len; i++) {
			var curFn = ary[i];
			try {
				xhr = curFn();
				createXHR = curFn;
				flag = true;
				break;
			} catch (e) {
				//
			}
		}

		if (!flag) {
			throw new Error("你的浏览器版本太低，不支持ajax，请更换浏览器再试");
		}
		return xhr;
		}

		window.BigSpinach_ajax = ajax;
	}();



##4 项目开发

![Alt text](./1536747607903.png)
api文档
![Alt text](./1536747679939.png)
1.
![Alt text](./1536747708780.png)
2.
![Alt text](./1536747747794.png)
3.
![Alt text](./1536747832917.png)
4
![Alt text](./1536747850900.png)
5.
![Alt text](./1536747860512.png)


![Alt text](./1536748078492.png)
![Alt text](./1536763482972.png)

![Alt text](./1536748036753.png)




###4.1 server.js


 ![Alt text](./1536764193956.png)
![Alt text](./1536764334513.png)
![Alt text](./1536764406490.png)


api数据接口处理
1）
![Alt text](./1536831668892.png)
![Alt text](./1536831678992.png)

![Alt text](./1536831731361.png)
![Alt text](./1536831778525.png)

![Alt text](./1536832178766.png)
2）
![Alt text](./1536832315742.png)
![Alt text](./1536832420612.png)
![Alt text](./1536832542203.png)

![Alt text](./1536832699465.png)

3）
![Alt text](./1536833189301.png)

![Alt text](./1536833777761.png)
![Alt text](./1536833789191.png)

![Alt text](./1536833883477.png)
![Alt text](./1536833895250.png)


4）
![Alt text](./1536834078543.png)

![Alt text](./1536835020033.png)
![Alt text](./1536835190022.png)
![Alt text](./1536835316465.png)
![Alt text](./1536835351485.png)


![Alt text](./1536835462973.png)
![Alt text](./1536835472425.png)

![Alt text](./1536835487165.png)


5）
![Alt text](./1536912048398.png)
![Alt text](./1536912085047.png)

![Alt text](./1536912094113.png)
![Alt text](./1536912143404.png)
![Alt text](./1536912170009.png)

![Alt text](./1536912192928.png)
![Alt text](./1536912206029.png)



![Alt text](./1536912151282.png)


![Alt text](./1536912306470.png)

`server.js`

		//1.导包
	var http = require('http');
	var url = require('url');
	var fs = require('fs');
	
	//2.创建服务
	var server1 = http.createServer(function(req, res) {
	
		//处理业务逻辑
	
		var urlObj = url.parse(req.url, true);
		var pathname = urlObj.pathname;
		var query = urlObj.query;
	
		//通过RegExp匹配所有MIME类型文件，配置静态文件
		var reg = /\.(HTML|CSS|JS|TXT|ICO|JSON|PNG|GIF|JPEG|SVG|JPG)/i;
		if (reg.test(pathname)) {
			var stuffix = reg.exec(pathname)[1].toUpperCase();
	
			var stuffixMIME = "text/plain";
	
			switch (stuffix) {
				case "HTML":
					stuffixMIME = "text/html";
					break;
				case "CSS":
					stuffixMIME = "text/css";
					break;
				case "JS":
					stuffixMIME = "text/javascript";
					break;
				case "TXT":
					stuffixMIME = "text/plain";
					break;
				case "JSON":
					stuffixMIME = "application/json";
					break;
				case "PNG":
					stuffixMIME = "image/png";
					break;
				case "ICO":
					stuffixMIME = "appliction/octet-stream";
					break;
				case "GIF":
					stuffixMIME = "image/gif";
					break;
				case "JPEG":
					stuffixMIME = "image/jpeg";
					break;
				case "SVG":
					stuffixMIME = "image/svg+xml";
					break;
				case "JPG":				
					stuffixMIME = "image/jpeg";
					break;
				default:
					stuffixMIME = "text/plain";
					break;
			}
	
			try {
				var conFile = fs.readFileSync('..' + pathname, 'utf-8');
					//console.log('..' + pathname);
						//    ../test.html
						//    ../img/dog_001.jpg
				//重写头部信息
				res.writeHead(200, {
					'content-type': stuffixMIME + ';charset=utf-8;'
				});
				res.end(conFile);
			} catch (e) {
				res.writeHead(404, {
					'content-type': 'text/html;charset=utf-8;'
				});
				res.end('node found this file');
			}
			return;
		}
	
	
		//res.writeHead(200,{'content-type':stuffixMIME+';charset=utf-8;'});
		//res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
		//Content-Type: text/html;charset=utf-8
		//res.end('开启服务成功。。。。');
	
		//API接口处理
		var con = null;
		var result = null;
		var customPath = "../json/custom.json";
		var customId = null;
	
		con = fs.readFileSync(customPath, "utf-8");
		con.length === 0 ? con = "[]" : null;
		con = JSON.parse(con);
	
		if (pathname === "/") {
			var conFile = fs.readFileSync('../test.html', 'utf-8');
			//重写头部信息
			res.writeHead(200, {
				'content-type': 'text/html;charset=utf-8;'
			});
			res.end(conFile);
		}
		//处理api接口
		//1）获取所有的客户信息 get 
		if (pathname === "/getList") {
			//编写默认返回的数据结构
			result = {
				code: 1,
				msg: "没有任何客户信息",
				data: null
			};
			//处理返回的数据
			if (con.length > 0) {
				result = {
					code: 0,
					msg: "success",
					data: con
				};
			}
	
			
			res.writeHead(200,{'content-type':'application/json;charset=utf-8;'});
			//将要返回的数据转为字符串格式返回
			res.end(JSON.stringify(result));
			return;
		};
	
		//2) 根据传递进来的id获取具体的某一个客户信息 get 
		if (pathname === "/getInfo") {
			//获取到客户端传递进来的id值 （一般存储在url的、？传参里边）
			customId = query["id"];
			//console.log(customId);
			result = {
				code: 1,
				msg: "此用户不存在",
				data: null
			};
	
			for (var i = 0, length1 = con.length; i < length1; i++) {
				if (con[i]["id"] == customId) {
					result = {
						code: 0,
						msg: " find success",
						data: con[i]
					};
					break;
				}
			}
			
			res.writeHead(200,{'content-type':'application/json;charset=utf-8;'});
			//将要返回的数据转为字符串格式返回
			res.end(JSON.stringify(result));
			return;
			
		}
	
		//3）根据传递进来的id，删除指定客户信息 get    /removeInfo?id=5
		if (pathname === "/removeInfo") {
			customId = query["id"];
			var flag = false;
			for (var i = 0, length1 = con.length; i < length1; i++) {
				if (con[i]["id"] == customId) {
					con.splice(i, 1);
					flag = true;
					break;
				}
			}
	
			result = {
				code: 1,
				msg: "删除失败"
			}
	
			if (flag) {
				fs.writeFileSync(customPath, JSON.stringify(con), "utf-8");
				result = {
					code: 0,
					msg: "删除成功"
				}
			}
	
			res.writeHead(200, {
				'content-type': 'application/json;charset=utf-8;'
			});
			res.end(JSON.stringify(result));
			return;
		}
	
		//4）增加客户信息 post
		if (pathname === "/addInfo") {
			var str = '';
			req.on("data", function(chunk) {
				//data 事件：服务器一点点接受客户端的数据，chunk就是每次接受到的数据
				str += chunk;
			});
	
			req.on("end", function() {
				//console.log(str);//{"name":"","age":"","phone":"","address":""}
				//end事件：服务器端接收完客户端的所有数据
				//if (str.length === 0) {
				//遍历str中的每一项，
				
				
				var flag =false;
				for(var key in JSON.parse(str)){
					if(JSON.parse(str)[key]===''){
						flag =true;
					}
					//console.log(JSON.parse(str)[key]);
				}
	
				if(flag){
					//如果传递过来的对象的所有属性的值都为空，则直接返回错误信息
					//说明客户端传递的数据为空
					res.writeHead(200, {
						'content-type': 'appliction/json;charset=utf-8;'
					});
					res.end(JSON.stringify({
						code: 1,
						msg: '增加失败'
					}));
					return;
				};
	
				//客户端传递过来有用的数据
				var data = JSON.parse(str);
				//设置新增进来的数据的id值
				data["id"] = con.length > 0 ? (con[con.length - 1]["id"] + 1) : 1;
				con.push(data);
	
				fs.writeFileSync(customPath, JSON.stringify(con), "utf-8");
				res.end(JSON.stringify({
					code: 0,
					msg: '增加成功'
				}));
			});
			return;
	
		}
	
		//5）修改客户信息 post
		if (pathname === "/updateInfo") {
			
			str = '';
			req.on("data", function(chunk) {
				str += chunk;
			});
	
			req.on("end", function() {	
				
				//修改的客户信息不存在
				if (str.length === 0) {
					res.writeHead(200, {
						'content-type': 'appliction/json;charset=utf-8;'
					});
					res.end(JSON.stringify({
						code: 1,
						msg: "要修改的客户不存在，修改失败"
					}));
					return;
				}
				//result.msg = "修改失败，没有传递任何要修改的信息";
				//修改的客户信息存在
				var flag = false;
				var data = JSON.parse(str);
				for(var i=0,len =con.length;i<len;i++){
					if(con[i]["id"] == data["id"]){
						con[i] = data;
						flag = true;
						break;
					}
				}
	
				if(true){
					//修改完成con后，需要把修改后的con返回给客户端
					fs.writeFileSync(customPath,JSON.stringify(con),"utf-8");
					result = {
						code :0,
						msg: "修改成功"
					};
					res.writeHead(200,{'content-type':'appliction/json;chetset=utf-8'});
					res.end(JSON.stringify(result));
				}
	
			});
			return;
		}
	
		/*
		if (pathname === "/img") {
			var conFile = fs.readFileSync('../img/dog_001.jpg', 'utf-8');
			//重写头部信息
			res.writeHead(200, {
				'content-type': 'image/jpeg;charset=utf-8;'
			});
			res.end(conFile);
		}
		*/
		//如果请求的api地址都不存在，返回下边的
		res.writeHead(404, {
			'content-type': 'text/plain;charset=utf-8;'
		});
		//将要返回的数据转为字符串格式返回
		res.end("请求的接口不存在");

	});
	
	//3.监听服务
	server1.listen(3300, function(err) {
		if (err) {
			console.log(err);
		} else {
			console.log('server running on port 3300');
		}
	})

###4.2 custom.json

![Alt text](./1536824267946.png)




###4.3 前端页面及其js

![Alt text](./1537175694581.png)

`单例模式`
####4.3.1 绑定所有客户信息
![Alt text](./1537175784660.png)
![Alt text](./1537176073344.png)


![Alt text](./1537175760462.png)



	var boxList = document.getElementById("boxList");
	//获取所有的客户信息，完成首页页面数据的绑定
	//单例模式
	var customModule = (function(){
		function bindHTML(data){

			//es5 字符串拼接的方式
			/*
			var str='';
			for (var i = 0;i<data.length;i++) {
				var curData = data[i];			
				str+='<li>';
				str+='<span  class="w50" >'+ curData['id']+'</span>';
				str+='<span  class="w50" >'+ curData['name']+'</span>';
				str+='<span  class="w150" >'+ curData['age']+'</span>';
				str+='<span  class="w200" >'+ curData['phone']+'</span>';
				str+='<span  class="w200" >'+ curData['address']+'</span>';
				str+='<span  class="w150 control">';
					str+='<a href="" >修改</a><a href="" >删除</a>';
				str+='</span>';	
				str+='</li>';
			}
			boxList.innerHTML =str;
			*/
			
			//es6 模板字符串
			var str='';
			for (var i = 0; i < data.length; i++) {
				var curDate =data[i];
				str+=`
					<li>
						<span  class="w50" >${curDate["id"]}</span>
						<span  class="w150">${curDate["name"]}</span>
						<span  class="w50">${curDate["age"]}</span>
						<span class="w200">${curDate["phone"]}</span>
						<span  class="w200">${curDate["address"]}</span>
						<span  class="w150 control">
							<a href="add.html?id=>${curDate['id']}" >修改</a>
							<a href="javascript:;" >删除</a>
						</span>			
					</li>
				`;
			}
			boxList.innerHTML =str;


		}

		function init(){
			/*			
				_default = {
					url: "",
					type: "get",
					dataType: "json",
					async: "true",
					data: null,
					getHead: null,
					success: null
				};
			 */

			BigSpinach_ajax({
				url : "/getList",
				success : function  (jsonData) {
					//获取得到的服务器端的数据的code = 0，说明获取数据成功了
					if(jsonData &&jsonData.code === 0){
						var data = jsonData['data'];
						//console.log(data);
						bindHTML(data);
					}
				}

			});
	


		}

		return {
			init : init
		}
	})();

	customModule.init();


####4.3.2 增加客户信息

![Alt text](./1537178551223.png)

![Alt text](./1537178911057.png)

![Alt text](./1537178938019.png)


![Alt text](./1537178953704.png)



![Alt text](./1537178991824.png)
####4.3.3  修改客户信息

![Alt text](./1537250327049.png)

![Alt text](./1537245589875.png)

![Alt text](./1537245699017.png)
![Alt text](./1537245713400.png)


获取url？后边的值，放入一个对象中存储
	
	//url地址？传参转为对象
	String.prototype.queryURLParameter = function(){
		var obj={},
			reg = /([^?=&#]+)=([^?=&#]+)/g;
		this.replace(reg,function(){
			var key = arguments[1],
				value =arguments[2];
			obj[key] = value;
		});
		return obj;
	}


`方法一：采用正则表达式获取地址栏参数：（ 强烈推荐，既实用又方便！）`

    //截取url数据方法
    var getParam = function (name) {
        var search = document.location.search;
        //alert(search);
        var pattern = new RegExp("[?&]" + name + "\=([^&]+)", "g");
        var matcher = pattern.exec(search);
        var items = null;
        if (null != matcher) {
            try {
                items = decodeURIComponent(decodeURIComponent(matcher[1]));
            } catch (e) {
                try {
                    items = decodeURIComponent(matcher[1]);
                } catch (e) {
                    items = matcher[1];
                }
            }
        }
        return items;
    };


`方法二：split拆分法`
	
	function GetRequest() {
	    var url = location.search; //获取url中"?"符后的字串
	    var theRequest = new Object();
	    if (url.indexOf("?") != -1) {
	        var str = url.substr(1);
	        strs = str.split("&");
	        for(var i = 0; i < strs.length; i ++) {
	            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
	        }
	    }
	    return theRequest;
	}
	var Request = new Object();
	Request = GetRequest();



####4.3.4   删除客户信息

![Alt text](./1537260129931.png)

自定义属性存储当前元素的id值
![Alt text](./1537260157687.png)

![Alt text](./1537260209473.png)
![Alt text](./1537260289166.png)



![Alt text](./1537260492313.png)



`add.html`

	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>BigSpinach-nodeAPI-test-add</title>
		<link rel="stylesheet" type="text/css" href="static/reset.css">
		<link rel="stylesheet" type="text/css" href="css/index.css">
	</head>
	<body>
		<div id="box2" class="box2">
			<div>
				<span>姓名:</span>
				<input type="text" id="userName">
			</div>
			<div>
				<span>年龄:</span>
				<input type="text" id="userAge">
			</div>
			<div>
				<span>电话:</span>
				<input type="text" id="userPhone">
			</div>
			<div>
				<span>住址:</span>
				<input type="text" id="userAddress">
			</div>
			<div>		
				<button type="button" class="submit" id="submit">提交</button>
			</div>
		</div>
	</body>
	<script src="static/BigSpinach_ajax.js"></script>
	<script>
	
		//url地址？传参转为对象
		String.prototype.queryURLParameter = function(){
			var obj={},
				reg = /([^?=&#]+)=([^?=&#]+)/g;
			this.replace(reg,function(){
				var key = arguments[1],
					value =arguments[2];
				obj[key] = value;
			});
			return obj;
		}
	
		//获取页面元素
		var userName = document.getElementById("userName"),
			userAge = document.getElementById("userAge"),
			userPhone = document.getElementById("userPhone"),
			userAddress = document.getElementById("userAddress");
		var	submit = document.getElementById("submit");
	
		
		
			//增加客户信息?修改？
		//增加思路 ： 获取页面中的表单信息，存储在一个对象中
		//		然后通过ajax的post请求传递给服务器端即可
			
		//判断一下是修改还是增加：
		//	依据：url ？ 后边的参数如果传递了id值就是修改，否则就是新增
		//	所以第一步：获取url后边传递进来的id的值
		var urlObj = window.location.href.queryURLParameter();
		
		var customId = urlObj['id'];
		isFlag = typeof customId === "undefined" ? false: true;
		
		//isFlag 标记，如果customId的值不存在，说明url后边没有传递id的值，说明是新增，标记为false，否则标记为true
		
		//修改客户信息
		//向服务器传递url信息（发送请求）
		if(isFlag){//true 表示url后边有id值，说明是修改	
			BigSpinach_ajax({
				url:"/getInfo?id="+customId,
				success:function(jsonData){
					if(jsonData && jsonData.code===0){
						var data =jsonData["data"];
						userName.value = data['name'];
						userAge.value = data['age'];
						userPhone.value = data['phone'];
						userAddress.value = data['address']				
					}
				}
			});
		}
	
		submit.onclick = function(){
	
			//创建存储对象
			var obj = {
				name : userName.value,
				age : userAge.value,
				phone : userPhone.value,
				address : userAddress.value,
			};
	
			//接收服务器端的响应结果
			if(isFlag){
				obj.id = customId;		
				BigSpinach_ajax({
					url :"/updateInfo",
					type:"post",
					data: JSON.stringify(obj),
					success:function(jsonData){
						if(jsonData && jsonData.code===0  && (JSON.stringify(obj).length>0)){					
							window.location.href = "index.html";	
							return;
						}
						alert(jsonData.msg);
					}
				});
				return;
			};
	
			//新增客户信息
			//发送ajax请求
			BigSpinach_ajax({
				url :'/addInfo',
				type:"post",
				async:"true",
				data : JSON.stringify(obj),
				success:function(jsonData){	
					if(jsonData && jsonData.code ===0){
						window.location.href = "index.html";
						return;
					}
					alert(jsonData.msg);
					window.location.href = "index.html";
				}
			});
			
			
		}
	</script>
	</html>



`index.html`
	
		<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>BigSpinach-nodeAPI-test-index</title>
		<link rel="stylesheet" type="text/css" href="static/reset.css">
		<link rel="stylesheet" href="css/index.css">
	</head>
	<body>
		<div id="box" class="box">
			<a href="add.html"  class="alink">增加新客户</a>
			<h2 class="head">
				<span class="w50">编号</span>
				<span class="w150">姓名</span>
				<span class="w50">年龄</span>
				<span class="w200">电话</span>
				<span class="w200">地址</span>
				<span class="w150">操作</span>
			</h2>
			<ul class="list" id="boxList">
				<!-- <li>
					<span  class="w50" >1</span>
					<span  class="w150">xxx</span>
					<span  class="w50">xxx</span>
					<span class="w200">18</span>
					<span  class="w200">18710906800</span>
					<span  class="w150 control">
						<a href="" >修改</a>
						<a href="" >删除</a>
					</span>			
				</li> -->			
			</ul>
	
		</div>
	</body>
	<script src="static/BigSpinach_ajax.js"></script>
	<script>
		var boxList = document.getElementById("boxList");
		//获取所有的客户信息，完成首页页面数据的绑定
		//单例模式
		var customModule = (function(){
			
			//删除客户信息
			function removeCustom(){
				//通过自定义属性customId获取到当前要被删除的元素的id值
				//通过事件委托的冒泡传播机制，给父级绑定事件
				boxList.onclick = function(e){
					e = e || window.event;
					var targetE = e.target || e.srcElement;
					//通过事件源来触发事件
					var targetE_name = targetE.tagName.toUpperCase();
				
					if (targetE_name === "A" && targetE.innerHTML==="删除"){
						//说明点击的是删除按钮
						//执行删除操作
						//
						//获取当前点击元素的自定义属性的id值
						var customId = targetE.getAttribute("customId");
	
						//1.获取弹出框的boolean值
						var flag = window.confirm("确定要删除编号为【"+customId+"】的客户信息吗");
	
						//2.如果是确定的话，就在dom里移除这一项
						if(flag){
							//移除当前元素的父级的父级li即可
							// boxList.removeChild(targetE.parentNode.parentNode);
							BigSpinach_ajax({
								url : "/removeInfo?id="+customId,
								success : function(jsonData){
									
									if(jsonData && jsonData.code===0){
										boxList.removeChild(targetE.parentNode.parentNode);
										return;
									}
									alert(jsonData.msg);
								}
							});
						}
					}
				}
			}
	
			function bindHTML(data){
	
				//es5 字符串拼接的方式
				/*
				var str='';
				for (var i = 0;i<data.length;i++) {
					var curData = data[i];			
					str+='<li>';
					str+='<span  class="w50" >'+ curData['id']+'</span>';
					str+='<span  class="w50" >'+ curData['name']+'</span>';
					str+='<span  class="w150" >'+ curData['age']+'</span>';
					str+='<span  class="w200" >'+ curData['phone']+'</span>';
					str+='<span  class="w200" >'+ curData['address']+'</span>';
					str+='<span  class="w150 control">';
						str+='<a href="" >修改</a><a href="" >删除</a>';
					str+='</span>';	
					str+='</li>';
				}
				boxList.innerHTML =str;
				*/
				
				//es6 模板字符串
				var str='';
				for (var i = 0; i < data.length; i++) {
					var curDate =data[i];
					str+=`
						<li>
							<span  class="w50" >${curDate["id"]}</span>
							<span  class="w150">${curDate["name"]}</span>
							<span  class="w50">${curDate["age"]}</span>
							<span class="w200">${curDate["phone"]}</span>
							<span  class="w200">${curDate["address"]}</span>
							<span  class="w150 control">
								<a href="add.html?id=${curDate['id']}" >修改</a>
								<a href="javascript:;" customId="${curDate["id"]}" >删除</a>
							</span>			
						</li>
					`;
				}
				boxList.innerHTML =str;
	
	
			}
	
			function init(){
				/*			
					_default = {
						url: "",
						type: "get",
						dataType: "json",
						async: "true",
						data: null,
						getHead: null,
						success: null
					};
				 */
	
				BigSpinach_ajax({
					url : "/getList",
					success : function  (jsonData) {
						//获取得到的服务器端的数据的code = 0，说明获取数据成功了
						if(jsonData &&jsonData.code === 0){
							var data = jsonData['data'];
							//console.log(data);
							bindHTML(data);
							removeCustom();
						}
					}
	
				});
			}
	
			return {
				init : init
			}
		})();
	
	customModule.init();
	
		// BigSpinach_ajax({
		// 	url : "/getList",
		// 	getHead :function(){
		// 		console.log(new Date());
		// 	},
		// 	success : function  (data) {
		// 		console.log(data);
		// 	}
	
		// });
		// 
	</script>
	</html>


